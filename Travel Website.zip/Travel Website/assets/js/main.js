/*=============== SHOW / HIDE MENU ===============*/
const navMenu = document.getElementById('nav__menu');
const navToggle = document.getElementById('nav-toggle');
const navClose = document.getElementById('nav-close');

/* Show menu */
if (navToggle && navMenu) {
  navToggle.addEventListener('click', () => {
    navMenu.classList.add('show-menu');
    navMenu.setAttribute('aria-hidden', 'false');
    navToggle.setAttribute('aria-expanded', 'true');
  });
}

/* Hide menu */
if (navClose && navMenu) {
  navClose.addEventListener('click', () => {
    navMenu.classList.remove('show-menu');
    navMenu.setAttribute('aria-hidden', 'true');
    navToggle?.setAttribute('aria-expanded', 'false');
  });
}

/* Remove menu on nav link click */
const navLinks = document.querySelectorAll('.nav__link');

if (navLinks.length && navMenu) {
  const closeMenuOnLink = () => {
    navMenu.classList.remove('show-menu');
    navMenu.setAttribute('aria-hidden', 'true');
    navToggle?.setAttribute('aria-expanded', 'false');
  };
  navLinks.forEach((link) => link.addEventListener('click', closeMenuOnLink));
}

/*=============== SWIPER HOME ===============*/
const swiperHome = new Swiper('.home__swiper', {
  loop: true,
  slidesPerView: 'auto',
  grabCursor: true,
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  speed: 800,
});

/*=============== CHANGE BACKGROUND HEADER ===============*/
const bgHeader = () => {
  const header = document.getElementById('header');
  // CORRECTED: Used window.scrollY for clarity
  window.scrollY > 50
    ? header.classList.add('bg-header')
    : header.classList.remove('bg-header');
};
window.addEventListener('scroll', bgHeader);

/*=============== SWIPER TESTIMONIAL ===============*/
const testimonial = new Swiper('.testimonial__swiper', {
  loop: true,
  slidesPerView: 'auto',
  spaceBetween: 48,
  grabCursor: true,
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
});

/*=============== SHOW SCROLL UP ===============*/
const scrollUp = () => {
  const scrollUpButton = document.getElementById('scroll-up');
  // CORRECTED: Used window.scrollY for clarity
  window.scrollY > 350
    ? scrollUpButton.classList.add('show-scroll')
    : scrollUpButton.classList.remove('show-scroll');
};
window.addEventListener('scroll', scrollUp);

/*=============== SCROLL SECTIONS ACTIVE LINK ===============*/
const sections = document.querySelectorAll('section[id]');

const scrollActive = () => {
  const scrollDown = window.scrollY;

  sections.forEach((current) => {
    const sectionHeight = current.offsetHeight;
    const sectionTop = current.offsetTop - 58;
    const sectionId = current.getAttribute('id');
    const sectionsClass = document.querySelector(
      '.nav__menu a[href*=' + sectionId + ']'
    );

    if (sectionsClass) {
      if (scrollDown > sectionTop && scrollDown <= sectionTop + sectionHeight) {
        sectionsClass.classList.add('active-link');
      } else {
        sectionsClass.classList.remove('active-link');
      }
    }
  });
};
window.addEventListener('scroll', scrollActive);

/*=============== DARK LIGHT THEME ===============*/
const themeButton = document.getElementById('theme-button');
const darkTheme = 'dark-theme';
const iconTheme = 'ri-sun-fill';

const selectedTheme = localStorage.getItem('selected-theme');
const selectedIcon = localStorage.getItem('selected-icon');

const getCurrentTheme = () =>
  document.body.classList.contains(darkTheme) ? 'dark' : 'light';
const getCurrentIcon = () =>
  themeButton.classList.contains(iconTheme) ? 'ri-moon-fill' : 'ri-sun-fill';

if (selectedTheme) {
  document.body.classList.toggle(darkTheme, selectedTheme === 'dark');
  themeButton.classList.toggle(iconTheme, selectedIcon === 'ri-sun-line');
}

themeButton.addEventListener('click', () => {
  document.body.classList.toggle(darkTheme);
  themeButton.classList.toggle(iconTheme);
  localStorage.setItem('selected-theme', getCurrentTheme());
  localStorage.setItem('selected-icon', getCurrentIcon());
});

/*=============== SCROLL REVEAL ANIMATION ===============*/
// ADDED: Implemented scroll reveal for the footer
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, {
    threshold: 0.1 // Trigger when 10% of the element is visible
});

const footer = document.querySelector('.footer');
if (footer) {
    observer.observe(footer);
}


/*=============== SCROLL REVEAL ANIMATION ===============*/
const sr = ScrollReveal({
  origin: 'top',
  distance: '60px',
  duration: 2000,
  delay: 300,
  // reset: true, // Animations repeat
});

sr.reveal('.home__container, .testimonial__container, .footer__container');
sr.reveal('.home__title', {
  delay: 600
});
sr.reveal('.home__description', {
  delay: 900
});
sr.reveal('.home__data .button', {
  delay: 1200
});
sr.reveal('.destination__card, .gallery__card', {
  interval: 100
});
sr.reveal('.join__data', {
  origin: 'left'
});
sr.reveal('.join__img', {
  origin: 'right'
});
